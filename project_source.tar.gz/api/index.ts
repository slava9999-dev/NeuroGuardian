// ============================================
// NeuroGUARDIAN — Unified API Handler
// Refactored: Uses middleware for auth, cleaner routing
// Version: 3.0.1 | Date: January 2026
// ============================================

import type { VercelRequest, VercelResponse } from '@vercel/node';

// Middleware (moved to src/api-lib to avoid Vercel function limit)
import {
  extractTelegramAuth,
  extractAnyAuthAsync,
  verifyAdminAccessAsync,
  sendAuthError,
  sendMethodNotAllowed,
} from '../src/api-lib/middleware/auth.js';

import { withSubscription } from '../src/api-lib/middleware/withSubscription.js';

// Route registry
import { AVAILABLE_ACTIONS } from '../src/api-lib/utils/routes.js';

// ============================================
// HANDLERS IMPORT
// ============================================

// Admin handlers
import {
  handleHealth,
  handleInitDb,
  handleResetDb,
  handleRunMigration,
  handleAdminActivateTrial,
  handleAdminCheckUser,
  handleAdminListUsers,
  handleAdminListProducts,
  handleSentinelLogs,
  handleAdminSentinelLogs,
  handleAdminSetProtection,
  handleAdminResetStatuses,
  handleAdminSetDefenseMode,
  handleAdminTestTelegram,
  handleAdminTestOzon,
  handleAdminTestWb,
  handleAdminCloneUser,
  handleSendReminders,
  handleReferral,
} from '../src/api-lib/handlers/admin.js';

import handleRagSetup from '../src/api-lib/handlers/rag-setup.js';

// Auth handlers
import { handleAuth, handleSettings, handlePlans } from '../src/api-lib/handlers/auth.js';

// Product handlers
import {
  handleProducts,
  handleSyncProducts,
  handleBatchSetStopLoss,
  handleApplyMinPrices,
  handleBatchUpdateCosts,
  handleLossProducts,
} from '../src/api-lib/handlers/products.js';

// Payment handlers
import { handleCreatePayment, handlePaymentWebhook } from '../src/api-lib/handlers/payments.js';

// Subscription handlers
import {
  handleGetSubscription,
  handleUpgradeSubscription,
  handleCancelSubscription,
  handleGetTiers,
  handleCheckLimits,
} from '../src/api-lib/handlers/subscription.js';

// Sentinel handlers
import {
  handleCheckPrices,
  handleSentinelStats,
  handleSentinelDashboard,
} from '../src/api-lib/handlers/sentinel.js';
import {
  handleSentinelStatus,
  handleDefenseHistory,
  handleToggleProtection,
  handleUpdateSentinelStatus,
  handleLogDefense,
  handleBulkLogDefense,
} from '../src/api-lib/handlers/sentinel-status.js';

// Agent handlers (V4 only)
import {
  handleAgentV4Secure,
  handleAgentV4Status,
  handleAgentV4ConfirmSecure,
} from '../src/api-lib/handlers/agent-v4.js';
import {
  handleAgentV5Secure,
  handleAgentV5Status,
  handleAgentV5ConfirmSecure,
} from '../src/api-lib/handlers/agent-v5.js';

// Chat handlers
import {
  handleGetChatHistory,
  handleSaveChatHistory,
  handleClearChatHistory,
} from '../src/api-lib/handlers/chat.js';

// Analytics handlers
import { handleGetAnalytics, handleGetSystemMetrics } from '../src/api-lib/handlers/analytics.js';

// Ops Panel handlers
import {
  handleOpsEvents,
  handleOpsAudit,
  handleOpsDashboard,
  handleOpsOverview,
  handleOpsClients,
  handleOpsAction,
} from '../src/api-lib/handlers/ops.js';

// Marketplace Accounts
import { handleMarketplaceAccounts } from '../src/api-lib/handlers/marketplace-accounts.js';

// Content Generation (SMM Module)
import { handleGenerateContent, handleContentQuota } from '../src/api-lib/handlers/content.js';

// // n8n Webhooks (DISABLED)
// import {
//   handleN8nPriceCheck,
//   handleN8nSyncProducts,
//   handleN8nHealth,
//   handleN8nSendReport,
//   handleN8nGetStats,
// } from '../src/api-lib/handlers/n8n-webhooks.js';

// MoE (Hybrid AI Router)
import {
  handleMoEClassify,
  handleMoEQuery,
  handleMoEHealth,
  handleMoEPriceCheck,
} from '../src/api-lib/handlers/moe.js';

// Media Handlers (Vision & Render)
import handleMediaUpload from '../src/api-lib/handlers/media-upload.js';
import handleMediaWebhook from '../src/api-lib/handlers/media-webhook.js';

// Telegram Bot Webhook
import {
  handleTelegramWebhook,
  setTelegramWebhook,
  getTelegramWebhookInfo,
} from '../src/api-lib/handlers/telegram.js';

// Validator Metrics (Analytics)
import {
  handleValidatorMetrics,
  handleThreatHistory,
  handleResetValidatorMetrics,
} from '../src/api-lib/handlers/validator-metrics.js';

// Utilities
import {
  sanitizeInput,
  checkRateLimitV2,
  RateLimitPresets,
  getRequestIdentifier,
  getRateLimitHeaders,
  IS_PRODUCTION,
  ALLOWED_ORIGINS,
} from '../src/api-lib/lib/index.js';
import { captureException } from '../src/api-lib/lib/monitoring.js';

// ============================================
// CORS HEADERS
// ============================================

function setCorsHeaders(req: VercelRequest, res: VercelResponse) {
  const origin = req.headers.origin || '';
  const isAllowed =
    !IS_PRODUCTION ||
    origin.includes('localhost') ||
    ALLOWED_ORIGINS.some(allowed => allowed && (origin === allowed || origin.startsWith(allowed)));

  res.setHeader('Access-Control-Allow-Origin', isAllowed ? origin || '*' : '');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Content-Type, Authorization, X-Init-Data, X-Admin-Key'
  );
  res.setHeader('Access-Control-Max-Age', '86400');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
}

// ============================================
// RATE LIMITING HELPER
// ============================================

/**
 * Apply rate limiting based on endpoint type
 */
async function applyRateLimit(
  req: VercelRequest,
  res: VercelResponse,
  action: string
): Promise<boolean> {
  const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0] || 'unknown';

  // Determine rate limit preset based on action
  let limit: number = RateLimitPresets.API.limit;
  let windowSeconds: number = RateLimitPresets.API.windowSeconds;
  let namespace = 'api';

  if (action.startsWith('admin-') || action === 'init-db' || action === 'reset-db') {
    limit = RateLimitPresets.ADMIN.limit;
    windowSeconds = RateLimitPresets.ADMIN.windowSeconds;
    namespace = 'admin';
  } else if (
    action === 'agent' ||
    action === 'agent-v4' ||
    action === 'agent-confirm' ||
    action.startsWith('moe-')
  ) {
    limit = RateLimitPresets.AGENT.limit;
    windowSeconds = RateLimitPresets.AGENT.windowSeconds;
    namespace = 'agent';
  } else if (action === 'check-prices') {
    limit = RateLimitPresets.SENTINEL.limit;
    windowSeconds = RateLimitPresets.SENTINEL.windowSeconds;
    namespace = 'sentinel';
  } else if (action === 'auth') {
    limit = RateLimitPresets.AUTH.limit;
    windowSeconds = RateLimitPresets.AUTH.windowSeconds;
    namespace = 'auth';
  }

  const identifier = getRequestIdentifier(undefined, clientIp);

  const result = await checkRateLimitV2({
    limit,
    windowSeconds,
    identifier,
    namespace,
  });

  // Set rate limit headers
  const headers = getRateLimitHeaders(result);
  Object.entries(headers).forEach(([key, value]) => {
    res.setHeader(key, value);
  });

  if (!result.allowed) {
    res.status(429).json({
      error: 'Too many requests',
      retryAfter: Math.ceil((result.reset - Date.now()) / 1000),
    });
    return false;
  }

  return true;
}

// ============================================
// MAIN HANDLER
// ============================================

// Kernel initialization state (cold start optimization)
let kernelInitialized = false;

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    setCorsHeaders(req, res);
    return res.status(200).end();
  }
  setCorsHeaders(req, res);

  // Auto-initialize System Kernel on first request (cold start)
  if (!kernelInitialized) {
    try {
      const { initializeKernel } = await import('../src/core/modules.js');
      const result = await initializeKernel();
      kernelInitialized = true;

      // Alert if any modules failed
      if (!result.success && result.errors.length > 0) {
        console.warn('[API] Kernel initialized with errors:', result.errors);
      }
    } catch (error) {
      // Non-blocking - system works without kernel, just less observable
      console.warn('[API] Kernel init skipped:', error instanceof Error ? error.message : error);
      kernelInitialized = true; // Don't retry on every request
    }
  }

  // Parse action
  const action = sanitizeInput((req.query.action as string) || req.body?.action);

  // Apply rate limiting based on action type
  const rateLimitPassed = await applyRateLimit(req, res, action);
  if (!rateLimitPassed) {
    return; // Response already sent by applyRateLimit
  }

  try {
    switch (action) {
      // ========== PUBLIC: NO AUTH ==========
      case 'health':
        return handleHealth(req, res);

      case 'payment-webhook':
        return handlePaymentWebhook(req, res);

      // ========== TELEGRAM BOT WEBHOOK ==========
      case 'telegram-webhook':
        return handleTelegramWebhook(req, res);

      case 'telegram-set-webhook': {
        // Admin only - set webhook URL
        const auth = await extractAnyAuthAsync(req);
        if (!auth.success || auth.context.authMethod !== 'admin') {
          return sendAuthError(res, 'Admin access required', 403);
        }
        const webhookUrl =
          req.body?.url || `https://neuro-guardian.vercel.app/api?action=telegram-webhook`;
        const result = await setTelegramWebhook(webhookUrl);
        return res.status(result.success ? 200 : 500).json(result);
      }

      case 'telegram-webhook-info': {
        // Admin only - get webhook info
        const auth = await extractAnyAuthAsync(req);
        if (!auth.success || auth.context.authMethod !== 'admin') {
          return sendAuthError(res, 'Admin access required', 403);
        }
        const info = await getTelegramWebhookInfo();
        return res.status(200).json(info);
      }

      // ========== AUTH ENDPOINTS ==========
      case 'auth': {
        if (req.method !== 'POST') return sendMethodNotAllowed(res);
        return handleAuth(req, res, sanitizeInput(req.body?.initData));
      }

      case 'plans': {
        const auth = extractTelegramAuth(req);
        return handlePlans(req, res, auth.success ? auth.context.userId : 0);
      }

      // ========== USER ENDPOINTS (TELEGRAM AUTH) ==========
      case 'products':
      case 'settings':
      case 'marketplace-accounts':
      case 'create-payment':
      case 'batch-set-stop-loss':
      case 'apply-min-prices':
      case 'batch-update-costs':
      case 'bulk-costs':
      case 'sentinel-logs': {
        const auth = await extractAnyAuthAsync(req);
        if (auth.success === false) {
          return sendAuthError(res, auth.error, auth.statusCode);
        }

        const handlers: Record<
          string,
          (req: VercelRequest, res: VercelResponse, userId: number) => Promise<VercelResponse>
        > = {
          products: handleProducts,
          settings: handleSettings,
          'marketplace-accounts': handleMarketplaceAccounts,
          'create-payment': handleCreatePayment,
          'batch-set-stop-loss': handleBatchSetStopLoss,
          'apply-min-prices': handleApplyMinPrices,
          'batch-update-costs': handleBatchUpdateCosts,
          'sentinel-logs': handleSentinelLogs,
          'loss-products': handleLossProducts,
          'generate-content': handleGenerateContent,
          'content-quota': handleContentQuota,
        };
        // ENFORCE SUBSCRIPTION
        return withSubscription(req, res, handlers[action], auth.context.userId);
      }

      case 'sync-products': {
        if (req.method !== 'POST') return sendMethodNotAllowed(res);
        const auth = await extractAnyAuthAsync(req);
        if (auth.success === false) {
          return sendAuthError(res, auth.error, auth.statusCode);
        }
        // ENFORCE SUBSCRIPTION
        return withSubscription(req, res, handleSyncProducts, auth.context.userId);
      }

      // ========== SUBSCRIPTION ENDPOINTS ==========
      case 'subscription':
      case 'upgrade-subscription':
      case 'cancel-subscription':
      case 'check-limits': {
        const auth = await extractAnyAuthAsync(req);
        if (auth.success === false) {
          return sendAuthError(res, auth.error, auth.statusCode);
        }

        const subscriptionHandlers: Record<
          string,
          (req: VercelRequest, res: VercelResponse, userId: number) => Promise<void>
        > = {
          subscription: handleGetSubscription,
          'upgrade-subscription': handleUpgradeSubscription,
          'cancel-subscription': handleCancelSubscription,
          'check-limits': handleCheckLimits,
        };
        return subscriptionHandlers[action](req, res, auth.context.userId);
      }

      case 'subscription-tiers':
        return handleGetTiers(req, res);

      // ========== SENTINEL ENDPOINTS ==========
      case 'check-prices':
        return handleCheckPrices(req, res);

      case 'sentinel-status':
        return handleSentinelStatus(req, res);

      case 'defense-history':
        return handleDefenseHistory(req, res);

      case 'toggle-protection':
        return handleToggleProtection(req, res);

      case 'update-sentinel-status':
        return handleUpdateSentinelStatus(req, res);

      case 'log-defense':
        return handleLogDefense(req, res);

      case 'bulk-log-defense':
        return handleBulkLogDefense(req, res);

      case 'sentinel-stats':
      case 'sentinel-dashboard':
      case 'sentinel-alerts': {
        const auth = await extractAnyAuthAsync(req);
        if (auth.success === false) {
          return sendAuthError(res, auth.error, auth.statusCode);
        }
        if (action === 'sentinel-stats') {
          return withSubscription(req, res, handleSentinelStats, auth.context.userId);
        }
        if (action === 'sentinel-alerts') {
          // Import sentinel agent
          const { sentinelAgent } = await import('../src/sentinel/SentinelAgent.js');
          const alerts = await sentinelAgent.monitorAllProducts();
          return res.status(200).json({ success: true, alerts });
        }
        return withSubscription(req, res, handleSentinelDashboard, auth.context.userId);
      }

      // ========== AI AGENT ENDPOINTS ==========
      case 'agent':
      case 'agent-v4':
      case 'agent-confirm':
      case 'agent-v4-confirm': {
        const auth = await extractAnyAuthAsync(req);
        if (auth.success === false) {
          return sendAuthError(res, auth.error, auth.statusCode);
        }

        const agentHandlers: Record<
          string,
          (req: VercelRequest, res: VercelResponse) => Promise<VercelResponse>
        > = {
          agent: handleAgentV5Secure,
          'agent-v4': handleAgentV4Secure,
          'agent-confirm': handleAgentV5ConfirmSecure,
          'agent-v4-confirm': handleAgentV4ConfirmSecure,
        };

        // Wrap handler to ignore 3rd argument (userId) if not used, or rely on internal auth re-check
        // strict wrapper: (q, s, u) => handler(q, s)
        return withSubscription(
          req,
          res,
          (q, s, _u) => agentHandlers[action](q, s),
          auth.context.userId
        );
      }

      case 'agent-status':
      case 'agent-v5-status':
        return handleAgentV5Status(req, res);

      case 'agent-v4-status':
        return handleAgentV4Status(req, res);

      // ========== CHAT HISTORY ==========
      case 'get-chat-history':
      case 'save-chat-history':
      case 'clear-chat-history': {
        const auth = await extractAnyAuthAsync(req);
        if (auth.success === false) {
          return sendAuthError(res, auth.error, auth.statusCode);
        }

        const chatHandlers: Record<
          string,
          (req: VercelRequest, res: VercelResponse, userId: number) => Promise<VercelResponse>
        > = {
          'get-chat-history': handleGetChatHistory,
          'save-chat-history': handleSaveChatHistory,
          'clear-chat-history': handleClearChatHistory,
        };
        return chatHandlers[action](req, res, auth.context.userId);
      }

      // ========== ANALYTICS ==========
      case 'get-analytics':
        return handleGetAnalytics(req, res);

      case 'get-system-metrics':
        return handleGetSystemMetrics(req, res);

      // ========== VALIDATOR METRICS (ANALYTICS) ==========
      case 'validator-metrics':
        return handleValidatorMetrics(req, res);

      case 'threat-history':
        return handleThreatHistory(req, res);

      case 'reset-validator-metrics':
        return handleResetValidatorMetrics(req, res);

      // ========== ADMIN ENDPOINTS ==========
      case 'init-db':
        return handleInitDb(req, res);

      case 'reset-db':
        return handleResetDb(req, res);

      case 'run-migration':
        return handleRunMigration(req, res);

      case 'rag-setup':
        return handleRagSetup(req, res);

      case 'admin-activate-trial':
        return handleAdminActivateTrial(req, res);

      case 'admin-check-user':
        return handleAdminCheckUser(req, res);

      case 'admin-list-users':
        return handleAdminListUsers(req, res);

      case 'admin-list-products':
        return handleAdminListProducts(req, res);

      case 'admin-set-protection':
        return handleAdminSetProtection(req, res);

      case 'admin-test-telegram':
        return handleAdminTestTelegram(req, res);

      case 'admin-reset-statuses':
        return handleAdminResetStatuses(req, res);

      case 'admin-set-defense-mode':
        return handleAdminSetDefenseMode(req, res);

      case 'admin-test-ozon':
        return handleAdminTestOzon(req, res);

      case 'admin-test-wb':
        return handleAdminTestWb(req, res);

      case 'admin-clone-user':
        return handleAdminCloneUser(req, res);

      // GOD MODE SYSTEM CONTROL
      case 'admin-system': {
        const { handleAdminSystem } = await import('../src/api-lib/handlers/admin-system.js');
        return handleAdminSystem(req, res);
      }

      case 'admin-sentinel-logs':
        return handleAdminSentinelLogs(req, res);

      case 'send-reminders':
        return handleSendReminders(req, res);

      case 'send-daily-report': {
        // Verify cron/admin access
        const isAdmin = await verifyAdminAccessAsync(req);
        if (!isAdmin) {
          return sendAuthError(res, 'Cron/Admin access required for daily report', 403);
        }
        // Import and call daily report handler
        const { default: handleDailyReport } = await import('./cron/send-daily-report.js');
        return handleDailyReport(req, res);
      }

      case 'referral':
        return handleReferral(req, res);

      // // ========== N8N WEBHOOKS (DISABLED) ==========
      // case 'n8n-price-check':
      //   return handleN8nPriceCheck(req, res);

      // case 'n8n-sync-products':
      //   return handleN8nSyncProducts(req, res);

      // case 'n8n-health':
      //   return handleN8nHealth(req, res);

      // case 'n8n-send-report':
      //   return handleN8nSendReport(req, res);

      // case 'n8n-get-stats':
      //   return handleN8nGetStats(req, res);

      // ========== OPS PANEL ENDPOINTS ==========
      case 'ops-events':
        return handleOpsEvents(req, res);

      case 'ops-audit':
        return handleOpsAudit(req, res);

      case 'ops-dashboard':
        return handleOpsDashboard(req, res);

      case 'ops-overview':
        return handleOpsOverview(req, res);

      case 'ops-clients':
        return handleOpsClients(req, res);

      case 'ops-action':
        return handleOpsAction(req, res);

      // ========== MOE (HYBRID AI) ENDPOINTS ==========
      case 'moe-health':
        return handleMoEHealth(req, res);

      case 'moe-classify':
      case 'moe-query':
      case 'moe-price-check': {
        const auth = await extractAnyAuthAsync(req);
        if (auth.success === false) {
          return sendAuthError(res, auth.error, auth.statusCode);
        }

        const moeHandlers: Record<
          string,
          (req: VercelRequest, res: VercelResponse, userId: number) => Promise<VercelResponse>
        > = {
          'moe-classify': handleMoEClassify,
          'moe-query': handleMoEQuery,
          'moe-price-check': handleMoEPriceCheck,
        };
        return moeHandlers[action](req, res, auth.context.userId);
      }

      // ========== MEDIA (VISION & RENDER) ==========
      case 'media-upload':
        // Auth is handled inside or requires valid session?
        // Let's assume public upload for now or consistent with other handlers
        // Ideally verify auth here
        return handleMediaUpload(req, res);

      case 'media-webhook':
        // No user auth required (secured by QStash signature inside handler)
        return handleMediaWebhook(req, res);

      // ========== DEFAULT ==========
      default:
        return res.status(400).json({
          error: 'Unknown action',
          availableActions: AVAILABLE_ACTIONS,
        });
    }
  } catch (error) {
    console.error('API Error:', error);
    captureException(error, {
      action,
      method: req.method,
      url: req.url,
    });
    return res.status(500).json({
      error: error instanceof Error ? error.message : 'Internal server error',
    });
  }
}
