// ============================================
// NeuroGUARDIAN — Agent Orchestrator v5
// Professional multi-agent architecture
// Version: 5.2.0 | Date: January 2026
// ============================================

import type {
  OrchestratorContext,
  OrchestratorResult,
  AgentPlan,
  ToolResult,
  ChatMessage,
} from '../../core/types/agent.types.js';

import { stateManager } from './StateManager.js';
import { contextResolver } from './ContextResolver.js';
import { promptBuilder } from './PromptBuilder.js';
import { memoryManager } from './MemoryManager.js';
import { experienceLearning } from './ExperienceLearning.js';
import { responseValidator } from './ResponseValidator.js';
import { toolRegistry } from '../execution/ToolRegistry.js';
import { llmRouter } from '../../infrastructure/llm/LLMRouter.js';
import { logger } from '../../api-lib/lib/logger.js';

import type { LLMMessage } from '../../infrastructure/llm/LLMProvider.js';

// ============================================
// TYPES
// ============================================

interface PhaseMetrics {
  planningTimeMs: number;
  executionTimeMs: number;
  answeringTimeMs: number;
}

// ============================================
// ORCHESTRATOR V5
// ============================================

/**
 * Agent Orchestrator v5
 *
 * Professional multi-agent architecture following course principles:
 * 1. Dynamic Prompt Assembly
 * 2. State Management
 * 3. Context Resolution
 * 4. Memory Integration
 *
 * Flow:
 * 1. Load State → Get user state from DB
 * 2. Resolve Context → Handle "2500" as cost_price answer
 * 3. Build Prompt → Dynamic assembly
 * 4. Plan → LLM decides which tools
 * 5. Execute → Run tools
 * 6. Answer → LLM generates response
 * 7. Validate → Check links, facts
 * 8. Save State → Persist for next message
 */
export class AgentOrchestratorV5 {
  // ✅ Memory integration enabled (Phase 3 complete)
  private memoryEnabled = true;

  /**
   * Main entry point
   */
  async orchestrate(
    message: string,
    context: OrchestratorContext,
    conversationHistory?: ChatMessage[]
  ): Promise<OrchestratorResult> {
    const startTime = Date.now();
    let tokensUsed = 0;
    const metrics: PhaseMetrics = {
      planningTimeMs: 0,
      executionTimeMs: 0,
      answeringTimeMs: 0,
    };

    logger.debug('Orchestrator V5 starting', { userId: context.userId });

    try {
      // ========================================
      // PHASE 0: Load State & Resolve Context
      // ========================================
      const userState = await stateManager.getState(context.userId);
      const resolvedContext = await contextResolver.resolve(context.userId, message);

      // Merge direct execution from context if provided
      if (context.directExecution && !resolvedContext.directExecution) {
        resolvedContext.directExecution = context.directExecution;
      }

      logger.debug('Context resolved', {
        isContextual: resolvedContext.isContextualResponse,
        type: resolvedContext.responseType,
        directExecution: !!resolvedContext.directExecution,
      });

      // ========================================
      // MEMORY: Save user message
      // ========================================
      if (this.memoryEnabled) {
        await memoryManager.saveMessage(context.userId, 'user', message);
        logger.debug('Memory: user message saved', { userId: context.userId });
      }

      // ========================================
      // SHORT-CIRCUIT: Direct Execution
      // ========================================
      if (resolvedContext.directExecution) {
        // Contextual response with known tool → execute directly
        const execStart = Date.now();

        const toolResult = await toolRegistry.execute(
          resolvedContext.directExecution.tool,
          context.userId,
          resolvedContext.directExecution.args
        );

        metrics.executionTimeMs = Date.now() - execStart;

        // Clear awaiting state
        await stateManager.clearAwaitingInput(context.userId);

        // Generate answer from tool result
        const answerStart = Date.now();
        const answer = await this.generateAnswer(
          resolvedContext.enrichedMessage,
          [{ ...toolResult, tool: resolvedContext.directExecution.tool }],
          userState,
          conversationHistory
        );
        metrics.answeringTimeMs = Date.now() - answerStart;
        tokensUsed += answer.tokensUsed;

        return this.buildResult(
          answer.message,
          answer.links,
          answer.actions,
          [resolvedContext.directExecution.tool],
          [toolResult],
          metrics,
          startTime,
          tokensUsed
        );
      }

      // ========================================
      // PHASE 1: Simple Intent Check
      // ========================================
      const simpleResponse = await this.handleSimpleIntent(message, context, userState);

      if (simpleResponse) {
        return this.buildSimpleResult(simpleResponse, startTime);
      }

      // ========================================
      // PHASE 2: Planning
      // ========================================
      const planStart = Date.now();

      const recentHistory = conversationHistory?.slice(-6) || [];
      const plannerPrompt = await promptBuilder.buildPlannerPrompt(
        {
          userState,
          recentHistory,
          isFirstContact: context.isFirstContact,
          userId: context.userId, // Enable memory context retrieval
        },
        resolvedContext.enrichedMessage
      );

      const planResult = await this.callPlanner(plannerPrompt, resolvedContext.enrichedMessage);

      metrics.planningTimeMs = Date.now() - planStart;
      tokensUsed += planResult.tokensUsed;

      if (!planResult.success || !planResult.plan) {
        return this.buildErrorResult(
          planResult.error || 'Не удалось составить план',
          metrics,
          startTime,
          tokensUsed
        );
      }

      const plan = planResult.plan;
      logger.debug('Plan created', {
        tools: plan.tools.map(t => t.tool),
        requiresConfirmation: plan.requiresConfirmation,
      });

      // ========================================
      // PHASE 3: Execution
      // ========================================
      const execStart = Date.now();

      const toolResults = await this.executeTools(plan, context.userId);

      metrics.executionTimeMs = Date.now() - execStart;

      // ========================================
      // PHASE 4: Answering
      // ========================================
      const answerStart = Date.now();

      const answer = await this.generateAnswer(
        message,
        toolResults,
        userState,
        conversationHistory
      );

      metrics.answeringTimeMs = Date.now() - answerStart;
      tokensUsed += answer.tokensUsed;

      // ========================================
      // PHASE 4.5: Response Validation (Guardrails)
      // ========================================
      let finalMessage = answer.message;

      try {
        const validation = await responseValidator.validate(answer.message, {
          userQuery: message,
          toolResults: toolResults.map(t => ({
            tool: t.tool,
            success: t.success,
            data: t.data,
          })),
          marketplace:
            userState.marketplace === 'WB'
              ? 'wb'
              : userState.marketplace === 'Ozon'
                ? 'ozon'
                : undefined,
        });

        if (!validation.isValid) {
          logger.warn('[Orchestrator] Response failed validation', {
            score: validation.score,
            issues: validation.issues.length,
          });

          // Use corrected response if available
          if (validation.correctedResponse) {
            finalMessage = validation.correctedResponse;
          }
        }
      } catch (validationError) {
        logger.warn('[Orchestrator] Validation failed', { error: validationError });
        // Continue with original response
      }

      // ========================================
      // PHASE 5: State Update
      // ========================================
      await this.updateStateAfterResponse(context.userId, message, plan, toolResults);

      // ========================================
      // MEMORY: Save assistant response & extract facts
      // ========================================
      if (this.memoryEnabled) {
        await memoryManager.saveMessage(context.userId, 'assistant', finalMessage);
        await this.extractAndSaveFacts(context.userId, message, finalMessage, toolResults);
        logger.debug('Memory: assistant response saved', { userId: context.userId });
      }

      // ========================================
      // EXPERIENCE LEARNING: Analyze interaction
      // ========================================
      try {
        // Get previous assistant message for correction detection
        const previousMessages = await memoryManager.getRecentHistory(context.userId, 3);
        const previousAgentMessage = previousMessages.find(m => m.role === 'assistant')?.content;

        await experienceLearning.analyzeInteraction(
          context.userId,
          message,
          finalMessage,
          previousAgentMessage
        );
      } catch (learnError) {
        logger.warn('Experience learning failed', { error: learnError });
      }

      // ========================================
      // Build Result
      // ========================================
      return this.buildResult(
        finalMessage,
        answer.links,
        answer.actions,
        plan.tools.map(t => t.tool),
        toolResults,
        metrics,
        startTime,
        tokensUsed,
        plan
      );
    } catch (error) {
      logger.error('Orchestrator V5 fatal error', error, { userId: context.userId });
      return {
        success: false,
        message: 'Произошла ошибка. Попробуй ещё раз.',
        planningTimeMs: metrics.planningTimeMs,
        executionTimeMs: metrics.executionTimeMs,
        answeringTimeMs: metrics.answeringTimeMs,
        totalTimeMs: Date.now() - startTime,
        tokensUsed,
        toolsCalled: [],
      };
    }
  }

  /**
   * Handle simple intents that don't need tools
   */
  private async handleSimpleIntent(
    message: string,
    context: OrchestratorContext,
    state: ReturnType<typeof stateManager.getState> extends Promise<infer T> ? T : never
  ): Promise<string | null> {
    const lower = message.toLowerCase().trim();

    // Greetings
    if (/^(привет|здравствуй|добрый|хай|хелло|hi|hello|hey)/.test(lower)) {
      const name = context.userName || 'друг';

      if (!state.hasWbKey && !state.hasOzonKey) {
        return `👋 Привет, ${name}!\n\n✅ **Подтверждаю — я вступил в должность управляющего вашим магазином!**\n\nМеня зовут Виктор. Чтобы начать работу, мне нужен доступ к вашему магазину.\n\n📌 Перейди в ⚙️ Настройки и подключи API-ключ Wildberries или Ozon.`;
      }

      return `👋 Привет, ${name}!\n\n📊 Вижу ваш магазин: **${state.productsCount}** товаров на ${state.marketplace || 'маркетплейсе'}.\n\nЧем могу помочь? Могу показать продажи, рассчитать прибыль или проверить конкурентов.`;
    }

    // Thanks
    if (/^(спасибо|благодарю|thanks|thank you)/.test(lower)) {
      return '😊 Всегда рад помочь! Обращайся, если что-то понадобится.';
    }

    // Help
    if (/^(помощь|help|что умеешь|\?)$/.test(lower)) {
      return `🤖 **Что я умею:**\n\n📊 **Аналитика:** продажи, прибыль, ABC-анализ\n🛡️ **Защита:** слежу за ценами 24/7\n📦 **Товары:** остатки, прогноз закончатся\n🔍 **Конкуренты:** проверяю цены\n\nПросто спроси — я разберусь!`;
    }

    return null;
  }

  /**
   * Call planner LLM
   */
  private async callPlanner(
    systemPrompt: string,
    userMessage: string
  ): Promise<{ success: boolean; plan?: AgentPlan; error?: string; tokensUsed: number }> {
    try {
      const messages: LLMMessage[] = [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userMessage },
      ];

      const result = await llmRouter.complete(messages, {
        temperature: 0.1,
        maxTokens: 500,
        jsonMode: true, // Force JSON for planner
      });

      // Parse JSON
      const parsed = JSON.parse(result.content);

      return {
        success: true,
        plan: {
          reasoning: parsed.reasoning || '',
          tools: parsed.tools || [],
          requiresConfirmation: parsed.requires_confirmation || false,
        },
        tokensUsed: result.tokensUsed,
      };
    } catch (error) {
      logger.error('Planner error', error);
      return {
        success: false,
        error: 'Не удалось обработать запрос',
        tokensUsed: 0,
      };
    }
  }

  /**
   * Execute tools from plan
   */
  private async executeTools(
    plan: AgentPlan,
    userId: number
  ): Promise<Array<ToolResult & { tool: string }>> {
    const results: Array<ToolResult & { tool: string }> = [];

    // Execute in parallel
    const promises = plan.tools.map(async planned => {
      try {
        const result = await toolRegistry.execute(planned.tool, userId, planned.args);
        return { ...result, tool: planned.tool };
      } catch (error) {
        return {
          tool: planned.tool,
          success: false,
          error: error instanceof Error ? error.message : String(error),
        };
      }
    });

    const executed = await Promise.all(promises);
    results.push(...executed);

    return results;
  }

  /**
   * Generate answer from tool results
   */
  private async generateAnswer(
    originalMessage: string,
    toolResults: Array<ToolResult & { tool: string }>,
    userState: Awaited<ReturnType<typeof stateManager.getState>>,
    conversationHistory?: ChatMessage[]
  ): Promise<{
    message: string;
    links?: OrchestratorResult['links'];
    actions?: OrchestratorResult['actions'];
    tokensUsed: number;
  }> {
    try {
      const systemPrompt = promptBuilder.buildAnswererPrompt({
        userState,
        recentHistory: conversationHistory || [],
      });

      const userMessage = `Пользователь спросил: "${originalMessage}"

Результаты инструментов:
${JSON.stringify(toolResults, null, 2)}

Сформируй ответ в формате JSON.`;

      const result = await llmRouter.complete(
        [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userMessage },
        ],
        { temperature: 0.3, maxTokens: 1500, jsonMode: true }
      );

      const parsed = JSON.parse(result.content);

      return {
        message: parsed.message || 'Готово!',
        links: parsed.links,
        actions: parsed.actions?.map(
          (a: {
            type: string;
            summary: string;
            details_json?: string;
            affected_count?: number;
          }) => ({
            type: a.type,
            summary: a.summary,
            details: a.details_json ? JSON.parse(a.details_json) : {},
            affectedCount: a.affected_count || 0,
          })
        ),
        tokensUsed: result.tokensUsed,
      };
    } catch (error) {
      logger.error('Answerer error', error);

      // Fallback: generate simple answer
      const successfulTools = toolResults.filter(r => r.success);
      if (successfulTools.length > 0) {
        return {
          message: `Готово! Выполнено ${successfulTools.length} действий.`,
          tokensUsed: 0,
        };
      }

      return {
        message: 'Не удалось выполнить запрос. Попробуй перефразировать.',
        tokensUsed: 0,
      };
    }
  }

  /**
   * Update state after response
   */
  private async updateStateAfterResponse(
    userId: number,
    query: string,
    _plan: AgentPlan,
    toolResults: Array<ToolResult & { tool: string }>
  ): Promise<void> {
    // Record query
    await stateManager.recordQuery(userId, query);

    // Track mentioned products
    const productIds: string[] = [];
    for (const result of toolResults) {
      if (result.success && result.data) {
        const data = result.data as { products?: Array<{ product_id: string }> };
        if (data.products) {
          productIds.push(...data.products.map(p => p.product_id));
        }
      }
    }

    if (productIds.length > 0) {
      await stateManager.trackMentionedProducts(userId, productIds);
    }
  }

  /**
   * Extract and save important facts to long-term memory
   * This enables the agent to remember important information across sessions
   */
  private async extractAndSaveFacts(
    userId: number,
    userMessage: string,
    _assistantResponse: string,
    toolResults: Array<ToolResult & { tool: string }>
  ): Promise<void> {
    try {
      // Extract cost_price facts from tool results
      for (const result of toolResults) {
        if (result.success && result.tool === 'set_cost_price' && result.data) {
          const data = result.data as { product_name?: string; cost_price?: number };
          if (data.product_name && data.cost_price) {
            await memoryManager.saveImportantFact(
              userId,
              `Себестоимость "${data.product_name}" = ${data.cost_price}₽`,
              'product_info',
              true // overwrite existing
            );
          }
        }

        // Extract min_price / stop-loss facts
        if (result.success && result.tool === 'set_stop_loss' && result.data) {
          const data = result.data as { product_name?: string; min_price?: number };
          if (data.product_name && data.min_price) {
            await memoryManager.saveImportantFact(
              userId,
              `Минимальная цена "${data.product_name}" = ${data.min_price}₽`,
              'product_info',
              true
            );
          }
        }
      }

      // Detect user preferences from message patterns
      const lowerMessage = userMessage.toLowerCase();

      if (
        lowerMessage.includes('кратко') ||
        lowerMessage.includes('коротко') ||
        lowerMessage.includes('без деталей')
      ) {
        await memoryManager.saveImportantFact(
          userId,
          'Предпочитает краткие ответы',
          'user_preference'
        );
      }

      if (
        lowerMessage.includes('подробно') ||
        lowerMessage.includes('детально') ||
        lowerMessage.includes('во всех подробностях')
      ) {
        await memoryManager.saveImportantFact(
          userId,
          'Предпочитает подробные ответы',
          'user_preference'
        );
      }

      // Detect business rules
      const marginMatch = lowerMessage.match(/маржа\s*(?:не менее|минимум|от)\s*(\d+)/i);
      if (marginMatch) {
        await memoryManager.saveImportantFact(
          userId,
          `Минимальная маржа ${marginMatch[1]}%`,
          'business_rule',
          true
        );
      }

      logger.debug('Memory facts extracted', { userId });
    } catch (error) {
      // Non-critical - don't fail the main flow
      logger.warn('Failed to extract memory facts', { error, userId });
    }
  }

  /**
   * Build success result
   */
  private buildResult(
    message: string,
    links: OrchestratorResult['links'],
    actions: OrchestratorResult['actions'],
    toolsCalled: string[],
    toolResults: ToolResult[],
    metrics: PhaseMetrics,
    startTime: number,
    tokensUsed: number,
    plan?: AgentPlan
  ): OrchestratorResult {
    return {
      success: true,
      message,
      links,
      actions,
      planningTimeMs: metrics.planningTimeMs,
      executionTimeMs: metrics.executionTimeMs,
      answeringTimeMs: metrics.answeringTimeMs,
      totalTimeMs: Date.now() - startTime,
      tokensUsed,
      toolsCalled,
      plan,
      toolResults,
    };
  }

  /**
   * Build simple result (no tools)
   */
  private buildSimpleResult(message: string, startTime: number): OrchestratorResult {
    return {
      success: true,
      message,
      planningTimeMs: 0,
      executionTimeMs: 0,
      answeringTimeMs: Date.now() - startTime,
      totalTimeMs: Date.now() - startTime,
      tokensUsed: 0,
      toolsCalled: [],
    };
  }

  /**
   * Build error result
   */
  private buildErrorResult(
    error: string,
    metrics: PhaseMetrics,
    startTime: number,
    tokensUsed: number
  ): OrchestratorResult {
    return {
      success: false,
      message: error,
      planningTimeMs: metrics.planningTimeMs,
      executionTimeMs: metrics.executionTimeMs,
      answeringTimeMs: metrics.answeringTimeMs,
      totalTimeMs: Date.now() - startTime,
      tokensUsed,
      toolsCalled: [],
    };
  }
}

// Memory service interface (for future use in Phase 3)
// interface MemoryServiceInterface {
//   getSessionHistory(sessionId: string): Promise<ChatMessage[]>;
//   searchRelatedContext(sessionId: string, query: string): Promise<string[]>;
// }

// Singleton instance
export const agentOrchestratorV5 = new AgentOrchestratorV5();

// Export orchestrate function for backward compatibility
export async function orchestrateV5(
  message: string,
  context: OrchestratorContext,
  conversationHistory?: ChatMessage[]
): Promise<OrchestratorResult> {
  return agentOrchestratorV5.orchestrate(message, context, conversationHistory);
}
